//Exemplo 01 da aula 01 de node.js
//Criando variaveis em node.js da aula 01

let nome = 'otavio pereira'
let cidade = 'nova londrina'
let idade = '39'

//console.log(nome, cidade, idade)
//console.log('meu nome é: ', nome)
console.log('meu nome é: ', nome)
console.log('moro em: ', cidade)
console.log('tenho: ', idade)
